extends Control

# UTMT Android - responsive mobile workspace
var current_file := ""
var file_data := PackedByteArray()
var tree: Tree
var content: TextEdit
var status: Label
var tabs: TabBar
var dialog: FileDialog
var save_dialog: FileDialog
var search_edit: LineEdit
var dirty := false
var current_mode := "Game Data"
var path_label: Label
var info_bar: Label

const RESOURCE_TABS = ["Sprites", "Objects", "Rooms", "Scripts", "Sounds", "Fonts", "Backgrounds", "Tilesets", "Paths", "Shaders", "Extensions"]

func _ready():
    _make_ui()
    _refresh_game_data()

func _make_ui():
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var bg = ColorRect.new()
    bg.color = Color("#0b0f16")
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)

    var root = VBoxContainer.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.offset_left = 10; root.offset_top = 8; root.offset_right = -10; root.offset_bottom = -8
    root.add_theme_constant_override("separation", 7)
    add_child(root)

    var header = PanelContainer.new()
    header.custom_minimum_size.y = 54
    header.add_theme_stylebox_override("panel", _panel_style("#151b26", "#293449", 8))
    root.add_child(header)
    var hb = HBoxContainer.new(); hb.add_theme_constant_override("separation", 6); header.add_child(hb)

    var title = Label.new(); title.text = "UTMT  •  Android"; title.add_theme_font_size_override("font_size", 20); title.add_theme_color_override("font_color", Color("#8bb8ff")); title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER; hb.add_child(title)
    var grow = Control.new(); grow.size_flags_horizontal = Control.SIZE_EXPAND_FILL; hb.add_child(grow)
    for data in [["Open", Callable(self,"_open")],["Save",Callable(self,"_save")],["Save As",Callable(self,"_save_as")]]:
        var b=Button.new(); b.text=data[0]; b.custom_minimum_size=Vector2(78,40); b.pressed.connect(data[1]); hb.add_child(b)

    tabs = TabBar.new(); tabs.custom_minimum_size.y = 40; tabs.size_flags_horizontal=Control.SIZE_EXPAND_FILL
    tabs.add_tab("Game Data")
    for t in RESOURCE_TABS: tabs.add_tab(t)
    tabs.add_tab("Hex Editor"); tabs.add_tab("Strings"); tabs.add_tab("Texture Tools")
    tabs.tab_changed.connect(_tab_changed)
    root.add_child(tabs)

    var toolbar = PanelContainer.new(); toolbar.custom_minimum_size.y=42; toolbar.add_theme_stylebox_override("panel",_panel_style("#111722","#252e3d",7)); root.add_child(toolbar)
    var tb=HBoxContainer.new(); tb.add_theme_constant_override("separation",6); toolbar.add_child(tb)
    search_edit=LineEdit.new(); search_edit.placeholder_text="Search data / resource..."; search_edit.size_flags_horizontal=Control.SIZE_EXPAND_FILL; search_edit.text_changed.connect(_search); tb.add_child(search_edit)
    var search=Button.new(); search.text="Search"; search.pressed.connect(_show_search); tb.add_child(search)
    var import_btn=Button.new(); import_btn.text="Import .droid"; import_btn.pressed.connect(_import_android_hint); tb.add_child(import_btn)

    var split=HSplitContainer.new(); split.size_flags_vertical=Control.SIZE_EXPAND_FILL; split.size_flags_horizontal=Control.SIZE_EXPAND_FILL; split.split_offset=300; root.add_child(split)

    var left=PanelContainer.new(); left.custom_minimum_size.x=260; left.add_theme_stylebox_override("panel",_panel_style("#111722","#252e3d",7)); split.add_child(left)
    var lv=VBoxContainer.new(); left.add_child(lv)
    var lt=Label.new(); lt.text="  PROJECT / GAME DATA"; lt.custom_minimum_size.y=34; lt.add_theme_color_override("font_color",Color("#91a4c2")); lv.add_child(lt)
    tree=Tree.new(); tree.columns=2; tree.hide_root=true; tree.size_flags_vertical=Control.SIZE_EXPAND_FILL; tree.item_selected.connect(_tree_selected); lv.add_child(tree)

    var right=PanelContainer.new(); right.size_flags_horizontal=Control.SIZE_EXPAND_FILL; right.add_theme_stylebox_override("panel",_panel_style("#0f141d","#252e3d",7)); split.add_child(right)
    var rv=VBoxContainer.new(); right.add_child(rv)
    var top=HBoxContainer.new(); top.custom_minimum_size.y=34; rv.add_child(top)
    path_label=Label.new(); path_label.text="No GameMaker data loaded"; path_label.add_theme_color_override("font_color",Color("#8f9bad")); path_label.size_flags_horizontal=Control.SIZE_EXPAND_FILL; top.add_child(path_label)
    status=Label.new(); status.text="Ready"; status.add_theme_color_override("font_color",Color("#7fdbb6")); top.add_child(status)
    info_bar=Label.new(); info_bar.text="Open data.win or game.droid to begin"; info_bar.custom_minimum_size.y=26; info_bar.add_theme_color_override("font_color",Color("#66758c")); rv.add_child(info_bar)
    content=TextEdit.new(); content.size_flags_vertical=Control.SIZE_EXPAND_FILL; content.size_flags_horizontal=Control.SIZE_EXPAND_FILL; content.add_theme_font_size_override("font_size",13); content.add_theme_color_override("font_color",Color("#d8dee9")); content.add_theme_color_override("caret_color",Color("#8bb8ff")); rv.add_child(content)

    var footer=Label.new(); footer.text="UTMT Android  •  Responsive workspace  •  Game data is kept unchanged until you save"; footer.custom_minimum_size.y=22; footer.add_theme_color_override("font_color",Color("#59677c")); root.add_child(footer)

    dialog=FileDialog.new()
    dialog.file_mode=FileDialog.FILE_MODE_OPEN_FILE
    dialog.access=FileDialog.ACCESS_FILESYSTEM
    dialog.filters=PackedStringArray(["*.droid ; GameMaker game.droid","*.win ; GameMaker data.win","*.dat ; Game data","*.* ; All files"])
    # Android: use the real Android Storage Access Framework picker instead of
    # Godot's large desktop-style FileDialog. The returned file is still opened
    # through FileAccess when the platform exposes a filesystem path.
    dialog.use_native_dialog = OS.has_feature("android")
    dialog.file_selected.connect(_load)
    add_child(dialog)

    save_dialog=FileDialog.new()
    save_dialog.file_mode=FileDialog.FILE_MODE_SAVE_FILE
    save_dialog.access=FileDialog.ACCESS_FILESYSTEM
    save_dialog.filters=PackedStringArray(["*.droid ; GameMaker game.droid","*.win ; GameMaker data.win","*.* ; Game data"])
    save_dialog.use_native_dialog = OS.has_feature("android")
    save_dialog.file_selected.connect(_save_to)
    add_child(save_dialog)

func _panel_style(bg:String,border:String,r:int)->StyleBoxFlat:
    var s=StyleBoxFlat.new(); s.bg_color=Color(bg); s.border_color=Color(border); s.set_border_width_all(1); s.corner_radius_top_left=r; s.corner_radius_top_right=r; s.corner_radius_bottom_left=r; s.corner_radius_bottom_right=r; return s

func _fill_tree(filter := ""):
    tree.clear()
    var root=tree.create_item(); root.set_text(0,"GAME DATA"); root.set_text(1,_bytes(file_data.size()))
    var entries=["File Information","Header / Magic","Binary Preview","GameMaker Resources","Texture Pages","Embedded Textures","Game Options","Global Variables","Code Entries","Search Bytes"]
    for n in entries:
        if filter=="" or n.to_lower().contains(filter.to_lower()): tree.create_item(root).set_text(0,n)
    var resroot=tree.create_item(); resroot.set_text(0,"RESOURCES"); resroot.set_text(1,str(RESOURCE_TABS.size()))
    for n in RESOURCE_TABS:
        if filter=="" or n.to_lower().contains(filter.to_lower()): tree.create_item(resroot).set_text(0,n)

func _search(text): _fill_tree(text)
func _open(): dialog.popup_centered_ratio(0.92)

func _import_android_hint():
    var p=_android_candidates()
    var found=[]
    for path in p:
        if FileAccess.file_exists(path): found.append(path)
    if found.size()>0:
        _load(found[0]); return
    content.text="IMPORT GAME.DROID — ANDROID\n\nAndroid APKs do not automatically expose arbitrary phone storage as a normal desktop filesystem.\n\nTry these supported locations first:\n• Download/game.droid\n• Documents/game.droid\n• Android/data/<package>/files/game.droid\n• app user://GameData/game.droid\n\nIf the Android picker cannot see shared storage, use the system file picker to copy game.droid into the app's GameData folder, then reopen it.\n\nDetected paths checked:\n"+"\n".join(p)

func _android_candidates()->Array:
    return ["/sdcard/Download/game.droid","/sdcard/Documents/game.droid","/storage/emulated/0/Download/game.droid","/storage/emulated/0/Documents/game.droid","user://GameData/game.droid"]

func _load(path):
    var f=FileAccess.open(path,FileAccess.READ)
    if f==null:
        status.text="Open failed"; info_bar.text="Android storage permission / picker may be required"; return
    current_file=path; file_data=f.get_buffer(f.get_length()); dirty=false
    path_label.text=path.get_file(); status.text="Loaded"; info_bar.text="%s  •  %s" % [path,_bytes(file_data.size())]
    _fill_tree(); _refresh_game_data()

func _save():
    if file_data.is_empty(): status.text="Nothing to save"; return
    if current_file=="": _save_as(); return
    _save_to(current_file+".modified")

func _save_as():
    save_dialog.current_file=current_file.get_file() if current_file!="" else "game.modified"; save_dialog.popup_centered_ratio(0.9)

func _save_to(path):
    var f=FileAccess.open(path,FileAccess.WRITE)
    if f==null: status.text="Cannot write"; return
    f.store_buffer(file_data); dirty=false; status.text="Saved"; info_bar.text="Saved: "+path

func _tree_selected(item:TreeItem,_column): _show_section(item.get_text(0))

func _show_section(name):
    if name=="File Information" or name=="Game Data": _refresh_game_data(); return
    if name=="Header / Magic": content.text=_header_report(); return
    if name=="Binary Preview": content.text=_hex_dump(0,min(file_data.size(),2048)); return
    if name=="Search Bytes": _show_search(); return
    if name=="GameMaker Resources": content.text="RESOURCE WORKSPACE\n\nSelect a resource tab to scan its signatures."; return
    if name in RESOURCE_TABS: _show_resource(name); return
    content.text=name.to_upper()+"\n\nNo structured entries detected yet. Use Strings, Hex Editor, or Search Bytes for this file."

func _refresh_game_data():
    if content==null: return
    if file_data.is_empty():
        content.text="GAME DATA\n\nNo file loaded.\n\nOpen a data.win / game.droid file.\nThe workspace will resize to the device automatically."
        return
    var magic=""; var lim=min(16,file_data.size())
    for i in range(lim): magic += "%02X " % file_data[i]
    content.editable=false
    content.text="GAME DATA\n\nFile: %s\nSize: %s\nPath: %s\nModified: %s\n\nHeader bytes:\n%s\n\nASCII preview:\n%s\n\nTOOLS\n• Resource browser\n• Hex editor\n• String extractor\n• Byte search\n• Texture signature scanner\n• Save / Save As" % [current_file.get_file(),_bytes(file_data.size()),current_file,"YES" if dirty else "NO",magic,_ascii_preview(0,min(64,file_data.size()))]

func _header_report():
    if file_data.is_empty(): return "HEADER / MAGIC\n\nOpen a file first."
    return "HEADER / MAGIC\n\nHex:\n%s\n\nASCII:\n%s\n\nFirst 4 bytes: %s" % [_hex_dump(0,min(64,file_data.size())),_ascii_preview(0,min(32,file_data.size())),_fourcc()]

func _show_resource(name):
    var signatures={"Sprites":["PNG","JPG","WEBP"],"Sounds":["OggS","WAV","MP3"],"Fonts":["TTF","OTF"],"Scripts":["function","return","var"],"Shaders":["shader","uniform"],"Extensions":[".dll",".so",".dylib"]}
    var found=[]
    for sig in signatures.get(name,[]):
        var hits=_find_ascii(sig)
        if hits.size()>0: found.append("%s: %d signature(s), first offset 0x%X" % [sig,hits.size(),hits[0]])
    content.text="%s\n\n%s\n\nSignature scan is active. Unknown GameMaker structures are left untouched." % [name.to_upper(),"\n".join(found) if found.size()>0 else "No common signatures found."]

func _tab_changed(index):
    var name=tabs.get_tab_title(index); current_mode=name
    if name=="Game Data": _refresh_game_data()
    elif name=="Hex Editor": _hex_editor()
    elif name=="Strings": _strings()
    elif name=="Texture Tools": _texture_tools()
    else: _show_resource(name)

func _hex_editor():
    if file_data.is_empty(): content.text="HEX EDITOR\n\nOpen a file first."; return
    content.editable=false; content.text=_hex_dump(0,min(file_data.size(),4096))

func _strings():
    if file_data.is_empty(): content.text="STRINGS\n\nOpen a file first."; return
    var out=[]; var cur=""
    for b in file_data:
        if b>=32 and b<=126: cur+=char(b)
        else:
            if cur.length()>=4: out.append(cur)
            cur=""
    if cur.length()>=4: out.append(cur)
    if out.size()>1000: out=out.slice(0,1000)
    content.editable=false; content.text="STRINGS (%d shown)\n\n%s" % [out.size(),"\n".join(out)]

func _texture_tools():
    content.editable=false; content.text="TEXTURE TOOLS\n\nLoaded file: %s\n\nDetected image signatures:\n%s\n\nThe scanner reports safe offsets without blindly rewriting texture blobs." % [current_file.get_file() if current_file!="" else "(none)",_signature_report()]

func _show_search():
    var q=search_edit.text.strip_edges()
    if q=="": content.text="SEARCH BYTES\n\nType ASCII text in the search box."; return
    var hits=_find_ascii(q); var lines=[]
    for off in hits.slice(0,min(200,hits.size())): lines.append("0x%08X  (%d)" % [off,off])
    content.editable=false; content.text="SEARCH: %s\n\nMatches: %d\n\n%s" % [q,hits.size(),"\n".join(lines)]

func _find_ascii(q:String)->Array:
    var needle=q.to_utf8_buffer(); var hits=[]
    if needle.is_empty(): return hits
    var n=needle.size()
    for i in range(0,max(0,file_data.size()-n+1)):
        var ok=true
        for j in range(n):
            if file_data[i+j]!=needle[j]: ok=false; break
        if ok: hits.append(i)
    return hits

func _signature_report():
    var sigs=["PNG","JPEG","RIFF","OggS","PK","DDS "]; var lines=[]
    for s in sigs:
        var h=_find_ascii(s); if h.size()>0: lines.append("%s → %d at 0x%X" % [s,h.size(),h[0]])
    return "\n".join(lines) if lines.size()>0 else "None found"

func _fourcc(): return _ascii_preview(0,min(4,file_data.size()))

func _ascii_preview(start:int,count:int)->String:
    var s=""
    for i in range(start,min(start+count,file_data.size())):
        var b=file_data[i]; s += char(b) if b>=32 and b<=126 else "."
    return s

func _hex_dump(start:int,count:int)->String:
    var lines=[]; var end=min(start+count,file_data.size()); var i=start
    while i<end:
        var h=""; var a=""
        for j in range(16):
            var p=i+j
            if p<end:
                h += "%02X " % file_data[p]; var b=file_data[p]; a += char(b) if b>=32 and b<=126 else "."
            else: h += "   "
        lines.append("%08X  %s |%s|" % [i,h,a]); i+=16
    return "\n".join(lines)

func _bytes(n:int)->String:
    if n<1024: return "%d B"%n
    if n<1048576: return "%.2f KB"%(n/1024.0)
    return "%.2f MB"%(n/1048576.0)
