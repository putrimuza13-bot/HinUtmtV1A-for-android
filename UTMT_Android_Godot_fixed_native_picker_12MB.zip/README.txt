UTMT Android - Godot starter project
====================================
This is a NEW Godot project, not a copy of the PC UndertaleModTool.

UI goal:
- White/light theme
- File/Edit/View/Tools/Help
- Game, Sprites, Objects, Rooms, Scripts, Sounds, Fonts,
  Backgrounds, Tilesets, Paths, Shaders, Extensions
- Hex Editor
- Texture Editor
- Searchable resource tree
- Open data.win / game.droid
- Save modified copy

Important:
This first build provides the Android/Godot interface and file-loading foundation.
A full UndertaleModTool-compatible parser/editor for data.win/game.droid is a much
larger implementation and must be added module by module.
